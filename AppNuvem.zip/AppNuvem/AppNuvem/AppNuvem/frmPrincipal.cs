﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppNuvem
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente();
                if (cliente.RegistroRepetido(txtcelular.Text) == true)
                {
                    MessageBox.Show("Este cliente já esta registrado.", "repetido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    DateTime datanasc = dpnascimento.Value.Date;
                    string genero = "";
                    if (cbgenero.Text.ToString() == "Masculino")
                    {
                        genero = "M";
                        label6.Text = genero;
                    }
                    else if (cbgenero.Text.ToString() == "Feminino")
                    {
                        genero = "F";
                        label6.Text = genero;
                    }
                    else
                    {
                        genero = "O";
                        label6.Text = genero;
                    }
                    cliente.Inserir(txtnome.Text, txtcelular.Text, datanasc, genero);
                    MessageBox.Show("Cliente inserido com sucesso", "Inserção",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    List<Cliente> clientes = cliente.listacliente();
                    dgvcliente.DataSource = clientes;
                    txtnome.Text = string.Empty;
                    txtcelular.Text = string.Empty;
                    cbgenero.Text = string.Empty;
                    dpnascimento.Text = string.Empty;
                    this.ActiveControl = txtnome;
                }
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message, "Erro Critico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            List<Cliente> clientes = cliente.listacliente();
            dgvcliente.DataSource = clientes;
            btneditar.Enabled = false;
            btnexcluir.Enabled = false;
            this.ActiveControl = txtnome;
        }

        private void btnfechar_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
