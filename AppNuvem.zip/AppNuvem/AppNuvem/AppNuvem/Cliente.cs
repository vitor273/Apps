﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace AppNuvem
{
    public class Cliente
    {   
        public int id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public DateTime datanasc { get; set; }
        public string genero { get; set; }
    


    MySqlConnection con = new MySqlConnection(@"server=sql.freedb.tech;port=3306;database=freedb_VitorDataBase;user id=freedb_abd1234;password=$BdSgG$h2Zf&4ME;charset=utf8");

        public List<Cliente> listacliente()
        {
            List<Cliente> li = new List<Cliente>();
            string sql = "SELECT * FROM clientes";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cliente c = new Cliente();
                c.id = (int)dr["id"];
                c.nome = dr["nome"].ToString();
                c.celular = dr["celular"].ToString();
                c.datanasc = (DateTime)dr["datanasc"];
                c.genero = dr["genero"].ToString();
                li.Add(c);
            }
            dr.Close();
            con.Close();
            return li;
        }

        public void Excluir(string nome, string celular, DateTime datanasc, string genero)
        {
            try
            {
                string sql = "DELETE FROM clientes SET WHERE id ='"+ id +"'";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message);
            }
        }
        public void Atualizar(string nome, string celular, DateTime datanasc, string genero)
        {
            try
            {
                string sql = "UPDATE clientes SET nome = '" + nome + "', celular = '" + celular + "', datanasc = '" + datanasc + "', genero = '" + genero + "'WHERE id = '"+id+"'";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message);
            }
        }
        public void Inserir(string nome, string celular, DateTime datanasc, string genero)
        {
            try
            {
                string sql = "INSERT INTO clientes(nome,celular,datanasc,genero) VALUES ('"+nome+"','"+celular+"','"+datanasc+"','"+genero+"')";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message);
            }
        }
        public bool RegistroRepetido(String celular)
        {
            string sql = "SELECT * FROM clientes WHERE celular='" + celular + "'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            var result = cmd.ExecuteScalar();
            if (result != null)
            {
                return true;
            }
            return false;
        }
        public void Localizar(int id)
        {
            string sql = "SELECT * FROM clientes WHERE id='" + id + "'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql,con);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                id = (int)dr["id"];
                nome = dr["nome"].ToString();
                celular = dr["celular"].ToString();
                datanasc = (DateTime)dr["datanasc"];
                genero = dr["genero"].ToString();
            }
            dr.Close();
            con.Close();
        }
    }
}
